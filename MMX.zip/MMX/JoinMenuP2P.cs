using System;
using System.Collections.Generic;
using System.Net;
using System.Threading;
using Lidgren.Network;
using Newtonsoft.Json;

namespace MMXOnline
{
    public class JoinMenuP2P : IMainMenu
    {
        public bool refreshing = true;
        public NetClient netClient;
        public long[] serverIndexes = new long[0];
        public Dictionary<long, (IPEndPoint intr, IPEndPoint extr)> serverList =
            new Dictionary<long, (IPEndPoint intr, IPEndPoint extr)>();
        public Dictionary<long, SimpleServerInfo> serverInfo =
            new Dictionary<long, SimpleServerInfo>();
        public int selServerIndex;
        public float refreshTimer;

        public JoinMenuP2P(bool isMenu)
        {
            MasterServerData.updateMasterServerURL();

            NetPeerConfiguration config = new NetPeerConfiguration("XOD-P2P-Vanilla");
            config.EnableMessageType(NetIncomingMessageType.ConnectionLatencyUpdated);
            config.EnableMessageType(NetIncomingMessageType.NatIntroductionSuccess);
            config.EnableMessageType(NetIncomingMessageType.UnconnectedData);
            config.AutoFlushSendQueue = false;
            config.ConnectionTimeout = Server.connectionTimeoutSeconds;

            netClient = new NetClient(config);
            netClient.Start();

            if (isMenu)
            {
                getServer();
            }
        }

        public void getServer()
        {
            refreshing = true;
            NetOutgoingMessage msg = netClient.CreateMessage();
            msg.Write((byte)MasterServerMsg.HostList);

            IPEndPoint masterServerLocation = NetUtility.Resolve(
                MasterServerData.serverIp,
                MasterServerData.serverPort
            );

            if (masterServerLocation != null)
            {
                netClient.SendUnconnectedMessage(msg, masterServerLocation);
                netClient.FlushSendQueue();
            }
        }

        public void update()
        {
            NetIncomingMessage msg;
            while ((msg = netClient.ReadMessage()) != null)
            {
                if (msg.MessageType == NetIncomingMessageType.UnconnectedData)
                {
                    byte messageType = msg.ReadByte();
                    switch (messageType)
                    {
                        case 100:
                            receiveHostList(msg);
                            refreshing = false;
                            break;
                        case 101:
                            var details = receiveServerDetails(msg);
                            if (details.Item2 != null)
                            {
                                joinServer(
                                    details.Item1,
                                    details.Item2,
                                    details.Item3,
                                    details.Item4
                                );
                                return;
                            }
                            break;
                    }
                }
            }

            refreshTimer += Global.spf;
            if (refreshTimer > 5f)
            {
                refreshTimer = 0;
                getServer();
            }

            if (Global.input.isPressedMenu(Control.MenuBack))
            {
                exit(new MainMenu());
                return;
            }

            if (serverIndexes.Length <= 0)
            {
                return;
            }

            Helpers.menuUpDown(ref selServerIndex, 0, serverIndexes.Length - 1);

            if (Global.input.isPressedMenu(Control.MenuSelectPrimary))
            {
                Action exitAction = () =>
                {
                    Menu.change(new ConnectionWaitMenuP2P(this, serverIndexes[selServerIndex]));
                };
                Menu.change(
                    new SelectCharacterMenu(
                        new MainMenu(), false, false, false,
                        false, false, false, exitAction
                    )
                );
            }
        }

        public void render()
        {
            DrawWrappers.DrawTextureHUD(Global.textures["menubackground"], 0, 0);

            Helpers.drawTextStd(
                TCat.Title, "JOIN P2P MATCH",
                Global.screenW * 0.5f, 20, Alignment.Center, fontSize: 40
            );

            if (refreshing && serverIndexes.Length == 0)
            {
                Helpers.drawTextStd(
                    TCat.Default, "Searching for matches...",
                    Global.halfScreenW, Global.halfScreenH, Alignment.Center, fontSize: 24
                );
            }
            else if (serverIndexes.Length == 0)
            {
                Helpers.drawTextStd(
                    TCat.Default, "No P2P matches found.",
                    Global.halfScreenW, Global.halfScreenH - 10, Alignment.Center, fontSize: 24
                );
                Helpers.drawTextStd(
                    TCat.Default, "Master: " + MasterServerData.serverIp + ":" + MasterServerData.serverPort,
                    Global.halfScreenW, Global.halfScreenH + 10, Alignment.Center, fontSize: 18
                );
            }
            else
            {
                float y = 50;
                for (int i = 0; i < serverIndexes.Length; i++)
                {
                    long key = serverIndexes[i];
                    if (!serverInfo.ContainsKey(key)) continue;
                    var info = serverInfo[key];
                    string forkTag = string.IsNullOrEmpty(info.fork) ? "" : ("  (" + info.fork + ")");
                    string line = string.Format(
                        "{0}  [{1}/{2}]  {3}  {4}{5}",
                        info.name,
                        info.playerCount,
                        info.maxPlayer,
                        info.mode,
                        info.map,
                        forkTag
                    );
                    Helpers.drawTextStd(
                        TCat.Option, line,
                        40, y, fontSize: 18, selected: i == selServerIndex
                    );
                    y += 14;
                    if (y > 180) break;
                }
            }

            Helpers.drawTextStd(
                TCat.BotHelp, "[X]: Join, [Z]: Back",
                Global.halfScreenW, 200, Alignment.Center, fontSize: 24
            );
        }

        public void exit(IMainMenu menu)
        {
            try
            {
                netClient?.Shutdown("Leaving P2P menu");
            }
            catch { }
            Menu.change(menu);
        }

        public void onExit(IMainMenu newMenu)
        {
        }

        public void receiveHostList(NetIncomingMessage msg)
        {
            List<long> serverKeys = new List<long>();
            serverList.Clear();
            serverInfo.Clear();

            while (msg.ReadByte() == 1)
            {
                long key = msg.ReadInt64();
                var endpoints = (msg.ReadIPEndPoint(), msg.ReadIPEndPoint());

                string name = msg.ReadString();
                byte maxPlayer = msg.ReadByte();
                byte playerCount = msg.ReadByte();
                string mode = msg.ReadString();
                string map = msg.ReadString();
                string fork = msg.ReadString();

                // Skip hosts from a different fork when both sides advertise a fork name
                if (!string.IsNullOrEmpty(fork) &&
                    !string.IsNullOrEmpty(Global.shortForkName) &&
                    !string.Equals(fork, Global.shortForkName, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                serverList[key] = endpoints;
                serverInfo[key] = new SimpleServerInfo(
                    name, maxPlayer, playerCount, mode, map, fork
                );
                serverKeys.Add(key);
            }

            serverIndexes = serverKeys.ToArray();
            if (selServerIndex >= serverIndexes.Length)
            {
                selServerIndex = Math.Max(0, serverIndexes.Length - 1);
            }
        }

        public void requestServerDetails(long serverId)
        {
            NetOutgoingMessage msg = netClient.CreateMessage();
            msg.Write((byte)MasterServerMsg.RequestDetails);
            msg.Write(serverId);

            IPEndPoint masterServerLocation = NetUtility.Resolve(
                MasterServerData.serverIp,
                MasterServerData.serverPort
            );

            if (masterServerLocation != null)
            {
                netClient.SendUnconnectedMessage(msg, masterServerLocation);
                netClient.FlushSendQueue();
            }
        }

        public (long, SimpleServerData, IPEndPoint, IPEndPoint) receiveServerDetails(
            NetIncomingMessage msg)
        {
            long serverId = msg.ReadInt64();
            string json = msg.ReadString();
            IPEndPoint endpoint = msg.ReadIPEndPoint();
            IPEndPoint radminEndpoint = null;

            if (msg.Position < msg.LengthBits - 2)
            {
                radminEndpoint = msg.ReadIPEndPoint();
            }

            SimpleServerData data =
                JsonConvert.DeserializeObject<SimpleServerData>(json);

            return (serverId, data, endpoint, radminEndpoint);
        }

        public void joinServer(
            long serverId,
            SimpleServerData serverdata,
            IPEndPoint ipEndPoint,
            IPEndPoint radminIP)
        {
            if (Helpers.compareVersions(Global.version, serverdata.gameVersion) == -1)
            {
                exit(new ErrorMenu(
                    new string[] {
                        "Your game version is too old. Update to v" +
                        serverdata.gameVersion.ToString()
                    }, new MainMenu()));
                return;
            }
            else if (Helpers.compareVersions(Global.version, serverdata.gameVersion) == 1)
            {
                exit(new ErrorMenu(
                    new string[] {
                        "The match game version (v" +
                        serverdata.gameVersion.ToString() + ") is too old."
                    }, new MainMenu()));
                return;
            }
            else if (Global.checksum != serverdata.gameChecksum)
            {
                exit(new ErrorMenu(new string[] {
                    "Client and server have different",
                    "checksum version numbers.",
                    "Yours: " + Global.checksum,
                    "Theirs: " + serverdata.gameChecksum
                }, new MainMenu()));
                return;
            }
            else if (!string.IsNullOrEmpty(serverdata.customMapChecksum))
            {
                var myLevelChecksum = LevelData.getChecksumFromName(serverdata.level);
                if (string.IsNullOrEmpty(myLevelChecksum))
                {
                    exit(new ErrorMenu(new string[] {
                        "Custom map \"" + serverdata.level + "\"",
                        "not found in maps_custom folder."
                    }, new MainMenu()));
                    return;
                }
                else if (myLevelChecksum != serverdata.customMapChecksum)
                {
                    exit(new ErrorMenu(new string[] {
                        "Client and server custom map",
                        "checksums do not match."
                    }, new MainMenu()));
                    return;
                }
            }

            string playerName = Options.main.playerName;
            var inputServerPlayer = new ServerPlayer(
                playerName, -1, false, SelectCharacterMenu.playerData.charNum,
                null, Global.deviceId, null, 0
            );

            Global.serverClient = ServerClient.CreateHolePunch(
                netClient, serverId, ipEndPoint, inputServerPlayer,
                out JoinServerResponse joinServerResponse, out string error
            );

            if (Global.serverClient == null)
            {
                exit(new ErrorMenu(
                    new string[] { "Connection error:", error ?? "Unknown" },
                    new MainMenu()
                ));
                return;
            }

            var server = joinServerResponse.server;
            if (Global.serverClient.serverPlayer.joinedLate)
            {
                Global.level = new Level(
                    server.getLevelData(), SelectCharacterMenu.playerData,
                    server.extraCpuCharData, true
                );
                Global.level.startLevel(joinServerResponse.server, true);
            }
            else
            {
                Menu.change(new WaitMenu(new MainMenu(), server, false));
            }
        }
    }
}
