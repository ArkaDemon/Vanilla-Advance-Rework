using Lidgren.Network;
using Newtonsoft.Json;
using System;
using System.Diagnostics;
using System.Net;
using System.Threading;

namespace MMXOnline
{
    public enum LeaveMatchScenario
    {
        LeftManually,
        MatchOver,
        ServerShutdown,
        Recreate,
        Rejoin,
        Kicked,
        // Master Server / P2P paths (aligned with Community Edition)
        RecreateMS,
        RejoinMS
    }

    public class LeaveMatchSignal
    {
        public LeaveMatchScenario leaveMatchScenario;
        public Server newServerData;
        public string kickReason;
        /// <summary>
        /// True when the match was hosted via Master Server / P2P (no region relay).
        /// </summary>
        public bool isMasterServer;

        public LeaveMatchSignal(
            LeaveMatchScenario leaveMatchScenario,
            Server newServerData,
            string kickReason,
            bool isMasterServer = false)
        {
            this.leaveMatchScenario = leaveMatchScenario;
            this.newServerData = newServerData;
            this.kickReason = kickReason;
            this.isMasterServer = isMasterServer;
        }

        public void createNewServer()
        {
            // P2P / Master Server: recreate local host (no region / relay)
            if (newServerData != null && (isMasterServer || newServerData.isP2P || newServerData.region == null))
            {
                reCreateMS();
                return;
            }

            if (newServerData?.region == null || string.IsNullOrEmpty(newServerData.region.ip))
            {
                Menu.change(new ErrorMenu("Error: Could not create new server (no region).", new MainMenu()));
                return;
            }

            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();
            byte[] serverResponse = null;
            do
            {
                serverResponse = Global.matchmakingQuerier.send(
                    newServerData.region.ip, "GetServer:" + newServerData.name, 1000);
                if (stopWatch.ElapsedMilliseconds > 5000)
                {
                    Menu.change(new ErrorMenu("Error: Could not create new server.", new MainMenu()));
                    return;
                }
            }
            while (!serverResponse.IsNullOrEmpty());

            HostMenu.createServer(
                SelectCharacterMenu.playerData.charNum, newServerData,
                null, true, new MainMenu(), out string errorMessage);

            if (!string.IsNullOrEmpty(errorMessage))
            {
                // Retry once (CE behavior)
                HostMenu.createServer(
                    SelectCharacterMenu.playerData.charNum, newServerData,
                    null, true, new MainMenu(), out errorMessage);
                if (!string.IsNullOrEmpty(errorMessage))
                {
                    Menu.change(new ErrorMenu(errorMessage, new MainMenu()));
                }
            }
        }

        public void rejoinNewServer()
        {
            // P2P / Master Server: auto-rejoin via Master Server details + NAT path
            if (newServerData != null && (isMasterServer || newServerData.isP2P || newServerData.region == null))
            {
                rejoinNewServerMS();
                return;
            }

            if (newServerData?.region == null || string.IsNullOrEmpty(newServerData.region.ip))
            {
                Menu.change(new ErrorMenu("Error: Could not rejoin new server.", new MainMenu()));
                return;
            }

            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();
            byte[] serverResponse;
            do
            {
                serverResponse = Global.matchmakingQuerier.send(
                    newServerData.region.ip, "GetServer:" + newServerData.name, 1000);
                if (stopWatch.ElapsedMilliseconds > 5000)
                {
                    Menu.change(new ErrorMenu("Error: Could not rejoin new server.", new MainMenu()));
                    return;
                }
            }
            while (serverResponse.IsNullOrEmpty());

            Server server = Helpers.deserialize<Server>(serverResponse);
            JoinMenu.joinServer(server);
        }

        /// <summary>
        /// Rejoin a P2P match after the host recreated it, using Master Server + uniqueID.
        /// </summary>
        public void rejoinNewServerMS()
        {
            if (newServerData == null || newServerData.uniqueID == 0)
            {
                string matchName = newServerData?.name ?? "";
                Menu.change(new ErrorMenu(
                    new string[]
                    {
                        "Host started a new match" + (string.IsNullOrEmpty(matchName) ? "." : (": " + matchName)),
                        "Select it again in the P2P list."
                    },
                    new JoinMenuP2P(true)
                ));
                return;
            }

            // Give host time to shut down old peer + re-register with Master
            Thread.Sleep(800);

            JoinMenuP2P joinMenu = new JoinMenuP2P(false);
            joinMenu.requestServerDetails(newServerData.uniqueID);
            joinMenu.netClient.FlushSendQueue();

            // ~12 seconds total, re-request details every ~1.5s
            const int maxLoops = 120;
            NetIncomingMessage msg;
            for (int i = 0; i <= maxLoops; i++)
            {
                while ((msg = joinMenu.netClient.ReadMessage()) != null)
                {
                    if (msg.MessageType == NetIncomingMessageType.UnconnectedData &&
                        msg.ReadByte() == 101)
                    {
                        var serverData = joinMenu.receiveServerDetails(msg);
                        if (serverData.Item2 != null)
                        {
                            joinMenu.joinServer(
                                serverData.Item1,
                                serverData.Item2,
                                serverData.Item3,
                                serverData.Item4);
                            return;
                        }
                    }
                }

                // Re-request periodically (host may still be registering / NAT settling)
                if (i > 0 && i % 15 == 0)
                {
                    joinMenu.requestServerDetails(newServerData.uniqueID);
                    joinMenu.netClient.FlushSendQueue();
                }
                Thread.Sleep(100);
            }

            // Timed out — fall back to manual P2P list
            try { joinMenu.netClient?.Shutdown("Rejoin MS timeout"); } catch { }
            string name = newServerData.name ?? "";
            Menu.change(new ErrorMenu(
                new string[]
                {
                    "Could not auto-rejoin P2P match" + (string.IsNullOrEmpty(name) ? "." : (": " + name)),
                    "Select it again in the P2P list."
                },
                new JoinMenuP2P(true)
            ));
        }

        /// <summary>
        /// Recreate local P2P host after map/mode change (Master Server path).
        /// </summary>
        public void reCreateMS()
        {
            if (newServerData == null)
            {
                Menu.change(new ErrorMenu("Error: Could not recreate P2P server.", new MainMenu()));
                return;
            }

            newServerData.isP2P = true;
            HostMenu.reCreateP2PMatch(
                SelectCharacterMenu.playerData.charNum,
                newServerData,
                new MainMenu(),
                out string errorMessage);

            if (!string.IsNullOrEmpty(errorMessage))
            {
                Menu.change(new ErrorMenu(errorMessage, new MainMenu()));
            }
        }
    }
}
