﻿using SFML.Graphics;
using System;
using static SFML.Window.Keyboard;

namespace MMXOnline
{
    /// <summary>
    /// Main menu (estilo referencia IntroMenu GIF):
    /// - mainmenutitle + onlinedeathmatch fijos
    /// - PLAY / CONFIG / QUIT en cian, selección &lt;PLAY&gt;
    /// - Entrada slide; al confirmar: squash/fade → transition frames → wipe → submenú
    /// </summary>
    public class MainMenu : IMainMenu
    {
        public int selectY;
        public float blinkTime;
        public string playerName = "";
        public int state;

        static readonly string[] options = { "PLAY", "CONFIG", "QUIT" };

        static readonly Color optionColor = new Color(80, 180, 220);
        static readonly Color optionSelectedColor = new Color(120, 230, 255);

        float titleAnimTimer;
        int titleFrameIndex;
        int titleFrameCount;
        bool titleFramesCached;
        const float titleFrameDuration = 0.1f;
        const string titleFramePrefix = "mainmenutitle";
        const string titleStaticKey = "mainmenutitle";
        const string subtitleKey = "onlinedeathmatch";

        float optionsEnterT;
        const float optionsEnterDuration = 0.40f;
        bool optionsEnterDone;

        enum ConfirmPhase
        {
            None,
            Squash,
            Transition,
            Wipe,
            Done
        }

        ConfirmPhase confirmPhase = ConfirmPhase.None;
        int confirmIndex;
        float phaseT;
        float transitionTimer;
        int transitionFrameIndex;
        int transitionFrameCount;
        bool transitionFramesCached;
        bool chingPlayed;

        const float squashDuration = 0.30f;
        const float wipeDuration = 0.45f;
        const float transitionFrameDuration = 0.06f;
        const string transitionFramePrefix = "transition";

        const float optionsStartYFactor = 0.48f;
        const float optionsLineHFactor = 0.085f;

        float uiFade = 1f;

        public MainMenu()
        {
            selectY = 0;
            confirmPhase = ConfirmPhase.None;
            optionsEnterT = 0;
            optionsEnterDone = false;
            uiFade = 1f;

            if (string.IsNullOrWhiteSpace(Options.main.playerName))
                state = 0;
            else if (Options.main.regionIndex == null)
                state = 1;
            else
                state = 3;
        }

        int countFramesWithPrefix(string prefix)
        {
            int count = 0;
            for (int i = 1; i <= 256; i++)
            {
                if (Global.textures.ContainsKey(prefix + i))
                    count = i;
                else
                    break;
            }
            return count;
        }

        public void update()
        {
            MenuBackgroundAnim.update();

            if (!titleFramesCached)
            {
                titleFrameCount = countFramesWithPrefix(titleFramePrefix);
                titleFramesCached = true;
            }

            updateTitleAnim();

            if (state == 0)
            {
                blinkTime += Global.spf;
                if (blinkTime >= 1f) blinkTime = 0;
                playerName = Helpers.getTypedString(playerName, Global.maxPlayerNameLength);
                if (Global.input.isPressed(Key.Enter) && !string.IsNullOrWhiteSpace(playerName.Trim()))
                {
                    Options.main.playerName = Helpers.censor(playerName).Trim();
                    Options.main.saveToFile();
                    state = 1;
                }
                return;
            }

            if (state == 1)
            {
                state = 3;
                return;
            }

            if (Global.input.isPressed(Key.F1))
            {
                Menu.change(new TextExportMenu(
                    new string[] { "Below is your checksum version:" },
                    "checksum", Global.checksum, this));
                return;
            }

            if (!optionsEnterDone)
            {
                optionsEnterT += Global.spf / optionsEnterDuration;
                if (optionsEnterT >= 1f)
                {
                    optionsEnterT = 1f;
                    optionsEnterDone = true;
                }
                return;
            }

            if (confirmPhase != ConfirmPhase.None)
            {
                updateConfirm();
                return;
            }

            Helpers.menuUpDown(ref selectY, 0, options.Length - 1);

            if (Global.input.isPressedMenu(Control.MenuSelectPrimary) ||
                Global.input.isPressed(Key.Enter))
            {
                beginConfirm();
            }
        }

        void updateTitleAnim()
        {
            if (titleFrameCount <= 0) return;
            titleAnimTimer += Global.spf;
            if (titleAnimTimer >= titleFrameDuration)
            {
                titleAnimTimer -= titleFrameDuration;
                titleFrameIndex = (titleFrameIndex + 1) % titleFrameCount;
            }
        }

        void beginConfirm()
        {
            confirmIndex = selectY;

            if (confirmIndex == 2)
            {
                System.Environment.Exit(0);
                return;
            }

            if (!transitionFramesCached)
            {
                transitionFrameCount = countFramesWithPrefix(transitionFramePrefix);
                transitionFramesCached = true;
            }

            confirmPhase = ConfirmPhase.Squash;
            phaseT = 0;
            transitionFrameIndex = 0;
            transitionTimer = 0;
            chingPlayed = false;
            uiFade = 1f;
        }

        void updateConfirm()
        {
            if (!chingPlayed)
            {
                chingPlayed = true;
                try { Global.playSound("ching"); } catch { }
            }

            switch (confirmPhase)
            {
                case ConfirmPhase.Squash:
                    phaseT += Global.spf / squashDuration;
                    if (phaseT >= 1f)
                    {
                        phaseT = 0;
                        if (transitionFrameCount > 0)
                            confirmPhase = ConfirmPhase.Transition;
                        else
                            confirmPhase = ConfirmPhase.Wipe;
                    }
                    break;

                case ConfirmPhase.Transition:
                    transitionTimer += Global.spf;
                    if (transitionTimer >= transitionFrameDuration)
                    {
                        transitionTimer -= transitionFrameDuration;
                        transitionFrameIndex++;
                        if (transitionFrameIndex >= transitionFrameCount)
                        {
                            phaseT = 0;
                            confirmPhase = ConfirmPhase.Wipe;
                        }
                    }
                    break;

                case ConfirmPhase.Wipe:
                    phaseT += Global.spf / wipeDuration;
                    uiFade = 1f - Helpers.clamp01(phaseT * 1.2f);
                    if (uiFade < 0f) uiFade = 0f;
                    if (phaseT >= 1f)
                    {
                        confirmPhase = ConfirmPhase.Done;
                        goToConfirmedMenu();
                    }
                    break;
            }
        }

        void goToConfirmedMenu()
        {
            confirmPhase = ConfirmPhase.None;
            if (confirmIndex == 0)
                Menu.change(new PlayMenu(this));
            else if (confirmIndex == 1)
                Menu.change(new ConfigMenu(this));
        }

        public void render()
        {
            MenuBackgroundAnim.draw();

            bool inWipe = confirmPhase == ConfirmPhase.Wipe;
            float fade = inWipe ? uiFade : 1f;

            if (fade > 0.01f)
            {
                drawTitle(fade);
                drawSubtitle(fade);
            }

            if (state == 3)
            {
                drawOptionsVertical();

                if (optionsEnterDone && confirmPhase == ConfirmPhase.None)
                {
                    Helpers.drawTextStd(
                        TCat.BotHelp,
                        "Up/Down Select   [Enter] Choose",
                        Global.screenW / 2f,
                        Global.screenH - 12,
                        Alignment.Center,
                        fontSize: 14
                    );
                }
            }

            if (confirmPhase == ConfirmPhase.Transition && transitionFrameCount > 0)
                drawTransitionOnOption(confirmIndex);

            if (confirmPhase == ConfirmPhase.Wipe)
                drawWipe(phaseT);

            string versionText = "v" + Global.version;
            if (Global.checksum != Global.prodChecksum)
                versionText = $"{versionText}  {Global.checksum}";
            if (confirmPhase == ConfirmPhase.None)
                Helpers.drawTextStd(versionText, 6, 4, Alignment.Left, fontSize: 14);

            if (state == 0)
            {
                float top = Global.screenH * 0.35f;
                DrawWrappers.DrawRect(0, 0, Global.screenW, Global.screenH, true,
                    new Color(0, 0, 0, 200), 0, ZIndex.HUD, false);
                Helpers.drawTextStd("Type in a multiplayer name",
                    Global.screenW / 2, top, alignment: Alignment.Center, fontSize: 24);
                float xPos = Global.screenW * 0.33f;
                Helpers.drawTextStd(playerName, xPos, 24 + top,
                    alignment: Alignment.Left, fontSize: 24);
                if (blinkTime >= 0.5f)
                {
                    float width = Helpers.measureTextStd(TCat.Default, playerName).x;
                    Helpers.drawTextStd("<", xPos + width + 3, 24 + top,
                        alignment: Alignment.Left, fontSize: 24);
                }
                Helpers.drawTextStd("Press Enter to continue",
                    Global.screenW / 2, 52 + top, alignment: Alignment.Center, fontSize: 20);
            }
        }

        void drawWipe(float t)
        {
            t = Helpers.clamp01(t);
            float cx = Global.screenW / 2f;
            float cy = Global.screenH / 2f;
            Color white = new Color(255, 255, 255, 255);

            if (t < 0.35f)
            {
                float u = t / 0.35f;
                float halfW = lerp(4f, Global.screenW * 0.5f + 4f, easeOutCubic(u));
                float lineH = 2f;
                DrawWrappers.DrawRect(
                    cx - halfW, cy - lineH * 0.5f,
                    cx + halfW, cy + lineH * 0.5f,
                    true, white, 0, ZIndex.HUD, false
                );
            }
            else
            {
                float u = (t - 0.35f) / 0.65f;
                u = easeOutCubic(Helpers.clamp01(u));

                float insetX = lerp(Global.screenW * 0.5f - 4f, 2f, u);
                float insetY = lerp(Global.screenH * 0.5f - 2f, 2f, u);
                float thickness = lerp(2f, 3f, u);

                float left = insetX;
                float right = Global.screenW - insetX;
                float top = insetY;
                float bot = Global.screenH - insetY;

                DrawWrappers.DrawRect(left, top, right, top + thickness, true, white, 0, ZIndex.HUD, false);
                DrawWrappers.DrawRect(left, bot - thickness, right, bot, true, white, 0, ZIndex.HUD, false);
                DrawWrappers.DrawRect(left, top, left + thickness, bot, true, white, 0, ZIndex.HUD, false);
                DrawWrappers.DrawRect(right - thickness, top, right, bot, true, white, 0, ZIndex.HUD, false);

                if (u > 0.5f)
                {
                    float fillA = (u - 0.5f) * 2f;
                    byte a = (byte)Helpers.clamp((int)(fillA * 220), 0, 220);
                    DrawWrappers.DrawRect(
                        left + thickness, top + thickness,
                        right - thickness, bot - thickness,
                        true, new Color(0, 0, 0, a), 0, ZIndex.HUD, false
                    );
                }
            }
        }

        Texture getTitleTexture()
        {
            if (titleFrameCount > 0)
            {
                if (titleFrameIndex >= titleFrameCount)
                    titleFrameIndex = 0;
                string key = titleFramePrefix + (titleFrameIndex + 1);
                if (Global.textures.ContainsKey(key))
                    return Global.textures[key];
            }
            if (Global.textures.ContainsKey(titleStaticKey))
                return Global.textures[titleStaticKey];
            return null;
        }

        void drawTitle(float alpha = 1f)
        {
            Texture tex = getTitleTexture();
            if (tex == null)
            {
                Helpers.drawTextStd(
                    TCat.Title, "MEGA MAN X ONLINE",
                    Global.screenW / 2f, Global.screenH * 0.18f,
                    Alignment.Center, fontSize: 36, alpha: alpha
                );
                return;
            }

            float tw = tex.Size.X;
            float th = tex.Size.Y;
            if (tw <= 0 || th <= 0) return;

            float maxW = Global.screenW * 0.92f;
            float maxH = Global.screenH * 0.38f;
            float scale = Math.Min(maxW / tw, maxH / th);

            float drawW = tw * scale;
            float dx = (Global.screenW - drawW) / 2f;
            float dy = Global.screenH * 0.06f;

            DrawWrappers.DrawTexture(
                tex, 0, 0, tw, th,
                dx, dy, ZIndex.HUD,
                cx: 0, cy: 0,
                xScale: scale, yScale: scale,
                angle: 0, alpha: alpha,
                shaders: null, isWorldPos: false
            );
        }

        void drawSubtitle(float alpha = 1f)
        {
            if (!Global.textures.ContainsKey(subtitleKey))
                return;

            Texture tex = Global.textures[subtitleKey];
            float tw = tex.Size.X;
            float th = tex.Size.Y;
            if (tw <= 0 || th <= 0) return;

            float maxW = Global.screenW * 0.45f;
            float maxH = Global.screenH * 0.10f;
            float scale = Math.Min(maxW / tw, maxH / th) * 0.70f;

            float drawW = tw * scale;
            float dx = (Global.screenW - drawW) / 2f;
            float dy = Global.screenH * 0.38f;

            DrawWrappers.DrawTexture(
                tex, 0, 0, tw, th,
                dx, dy, ZIndex.HUD,
                cx: 0, cy: 0,
                xScale: scale, yScale: scale,
                angle: 0, alpha: alpha,
                shaders: null, isWorldPos: false
            );
        }

        static float easeOutCubic(float t)
        {
            float u = 1f - t;
            return 1f - u * u * u;
        }

        static float lerp(float a, float b, float t)
        {
            return a + (b - a) * t;
        }

        void drawOptionsVertical()
        {
            float startY = Global.screenH * optionsStartYFactor;
            float lineH = Global.screenH * optionsLineHFactor;
            float centerX = Global.screenW / 2f;
            float slot = Global.screenW * 0.55f;

            float ease = easeOutCubic(Helpers.clamp01(optionsEnterT));
            float squashT = (confirmPhase == ConfirmPhase.Squash) ? phaseT
                : (confirmPhase != ConfirmPhase.None ? 1f : 0f);

            for (int i = 0; i < options.Length; i++)
            {
                bool fromLeft = (i == 0 || i == 2);
                float startX = fromLeft ? centerX - slot : centerX + slot;
                float x = optionsEnterDone ? centerX : lerp(startX, centerX, ease);
                float y = startY + i * lineH;

                bool selected = (i == selectY) && optionsEnterDone && confirmPhase == ConfirmPhase.None;
                bool isConfirmTarget = confirmPhase != ConfirmPhase.None && i == confirmIndex;
                bool isOther = confirmPhase != ConfirmPhase.None && i != confirmIndex;

                float alpha = 1f;
                if (isOther)
                    alpha = 1f - Helpers.clamp01(squashT * 2.5f);
                else if (isConfirmTarget)
                    alpha = 1f - easeOutCubic(Helpers.clamp01(squashT));

                if (confirmPhase == ConfirmPhase.Wipe || confirmPhase == ConfirmPhase.Transition)
                    alpha = 0f;

                if (alpha <= 0.02f) continue;

                Color baseCol = selected ? optionSelectedColor : optionColor;
                if (isConfirmTarget)
                    baseCol = optionSelectedColor;

                string label = options[i];
                if (selected || (isConfirmTarget && squashT < 1f))
                    label = "<" + options[i] + ">";

                Helpers.drawTextStd(
                    TCat.Default,
                    label,
                    x,
                    y,
                    Alignment.Center,
                    fontSize: 24,
                    color: baseCol,
                    selected: false,
                    alpha: alpha
                );
            }
        }

        void drawTransitionOnOption(int optionIndex)
        {
            int frameNum = transitionFrameIndex + 1;
            if (frameNum < 1) frameNum = 1;
            if (frameNum > transitionFrameCount) frameNum = transitionFrameCount;

            string key = transitionFramePrefix + frameNum;
            if (!Global.textures.ContainsKey(key))
                return;

            Texture tex = Global.textures[key];
            float tw = tex.Size.X;
            float th = tex.Size.Y;
            if (tw <= 0 || th <= 0) return;

            // Medir el texto de la opción para centrar el efecto encima
            int idx = optionIndex;
            if (idx < 0) idx = 0;
            if (idx >= options.Length) idx = options.Length - 1;
            string label = "<" + options[idx] + ">";
            Point textSize = Helpers.measureTextStd(TCat.Default, label, outline: true, fontSize: 24);
            float textW = Math.Max(textSize.x, 40f);
            float textH = Math.Max(textSize.y, 12f);

            // Escalar para cubrir el texto (un poco más grande)
            float maxW = Math.Max(textW * 1.6f, Global.screenW * 0.22f);
            float maxH = Math.Max(textH * 2.2f, Global.screenH * 0.08f);
            float scale = Math.Min(maxW / tw, maxH / th);

            float drawW = tw * scale;
            float drawH = th * scale;

            float startY = Global.screenH * optionsStartYFactor;
            float lineH = Global.screenH * optionsLineHFactor;
            // optionY = Y superior del texto (VAlignment.Top)
            float optionY = startY + optionIndex * lineH;

            // Centro exacto del label
            float textCenterX = Global.screenW / 2f;
            float textCenterY = optionY + textH * 0.5f;

            float dx = textCenterX - drawW * 0.5f;
            float dy = textCenterY - drawH * 0.5f;

            DrawWrappers.DrawTexture(
                tex, 0, 0, tw, th,
                dx, dy, ZIndex.HUD,
                cx: 0, cy: 0,
                xScale: scale, yScale: scale,
                angle: 0, alpha: 1f,
                shaders: null, isWorldPos: false
            );
        }
    }
}