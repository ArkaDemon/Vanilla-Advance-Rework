using Lidgren.Network;
using System;
using System.Net;
using System.Net.Sockets;

namespace MMXOnline
{
    public static class MasterServerData
    {
        // IP/dominio del Master Server (solo listado + NAT punch, NO relay de gameplay).
        public static string serverIp = "oh3.uniplex.xyz";

        // Puerto UDP del Master Server.
        public static int serverPort = 3026;

        /// <summary>
        /// Carga la URL del master server desde ./serverurl.txt (formato host:port)
        /// o, si no existe, desde una URL remota opcional.
        /// </summary>
        public static void updateMasterServerURL()
        {
            string[] portUrl = null;

            try
            {
                if (Helpers.FileExists("./serverurl.txt"))
                {
                    string contents = Helpers.ReadFromFile("./serverurl.txt");
                    if (!string.IsNullOrWhiteSpace(contents))
                    {
                        portUrl = contents.Trim().Split(':');
                    }
                }
            }
            catch { }

            if (portUrl == null || portUrl.Length != 2)
            {
                try
                {
                    // Opcional: cambia esta URL por la de tu master server publico.
                    string contents;
                    using (var wc = new System.Net.WebClient())
                    {
                        contents = wc.DownloadString(
                            "https://mmx-online-hdm.github.io/serverinfo/serverurl.txt"
                        );
                    }
                    if (!string.IsNullOrWhiteSpace(contents))
                    {
                        portUrl = contents.Trim().Split(':');
                    }
                }
                catch
                {
                    return;
                }
            }

            if (portUrl == null || portUrl.Length != 2)
            {
                return;
            }

            try
            {
                IPAddress[] addresses = Dns.GetHostAddresses(
                    portUrl[0], AddressFamily.InterNetwork
                );
                if (addresses.Length == 0)
                {
                    return;
                }
                if (!string.IsNullOrEmpty(addresses[0].ToString()))
                {
                    serverIp = addresses[0].ToString();
                    serverPort = int.Parse(portUrl[1]);
                }
            }
            catch { }
        }
    }

    public enum MasterServerMsg
    {
        HostList,
        ConnectPeersLong,
        RequestDetails,
        RegisterHost,
        RegisterDetails,
        RegisterInfo,
        UpdatePlayerNum,
        DeleteHost,
        ConnectPeersShort
    }

    public class SimpleServerData
    {
        public string name;
        public string level;
        public decimal gameVersion;
        public string gameChecksum;
        public string customMapChecksum;
        public string customMapUrl;

        public SimpleServerData(
            string name,
            string level,
            decimal gameVersion,
            string gameChecksum,
            string customMapChecksum,
            string customMapUrl)
        {
            this.name = name;
            this.level = level;
            this.gameVersion = gameVersion;
            this.gameChecksum = gameChecksum;
            this.customMapChecksum = customMapChecksum;
            this.customMapUrl = customMapUrl;
        }
    }

    public class SimpleServerInfo
    {
        public string name;
        public byte playerCount;
        public byte maxPlayer;
        public string mode;
        public string map;
        public string fork;

        public SimpleServerInfo(
            string name,
            byte maxPlayer,
            byte playerCount,
            string mode,
            string map,
            string fork)
        {
            this.name = name;
            this.maxPlayer = maxPlayer;
            this.playerCount = playerCount;
            this.mode = mode;
            this.map = map;
            this.fork = fork;
        }
    }

    public class ConnectionWaitMenuP2P : IMainMenu
    {
        public JoinMenuP2P joinMenu;
        public long serverID;
        public bool triedJoinOnce;
        public float waitTime;

        public ConnectionWaitMenuP2P(JoinMenuP2P joinMenu, long serverID)
        {
            this.joinMenu = joinMenu;
            this.serverID = serverID;
        }

        public void update()
        {
            if (!triedJoinOnce)
            {
                triedJoinOnce = true;
                joinMenu.requestServerDetails(serverID);
                joinMenu.netClient.FlushSendQueue();
            }

            waitTime += Global.spf;

            NetIncomingMessage msg;
            while ((msg = joinMenu.netClient.ReadMessage()) != null)
            {
                if (msg.MessageType == NetIncomingMessageType.UnconnectedData)
                {
                    byte messageType = msg.ReadByte();
                    if (messageType == 101)
                    {
                        var details = joinMenu.receiveServerDetails(msg);
                        if (details.Item2 != null)
                        {
                            joinMenu.joinServer(
                                details.Item1,
                                details.Item2,
                                details.Item3,
                                details.Item4
                            );
                            return;
                        }
                    }
                }
            }

            // Reintentar pedir detalles periodicamente (2s, 4s, 6s, 9s, 12s)
            if ((waitTime > 2f && waitTime < 2.1f) ||
                (waitTime > 4f && waitTime < 4.1f) ||
                (waitTime > 6f && waitTime < 6.1f) ||
                (waitTime > 9f && waitTime < 9.1f) ||
                (waitTime > 12f && waitTime < 12.1f))
            {
                joinMenu.requestServerDetails(serverID);
                joinMenu.netClient.FlushSendQueue();
            }

            // Timeout mas largo para P2P / NAT lento
            if (waitTime > 15f)
            {
                Menu.change(new ErrorMenu(
                    new string[] { "Could not connect to P2P match.", "Host may be offline or behind strict NAT." },
                    new JoinMenuP2P(true)
                ));
            }

            if (Global.input.isPressedMenu(Control.MenuBack))
            {
                Menu.change(new JoinMenuP2P(true));
            }
        }

        public void render()
        {
            DrawWrappers.DrawTextureHUD(Global.textures["menubackground"], 0, 0);
            Helpers.drawTextStd(
                TCat.Default, "Connecting (P2P)...",
                Global.halfScreenW, Global.halfScreenH, Alignment.Center, fontSize: 24
            );
        }

        public void onExit(IMainMenu newMenu)
        {
        }
    }
}
