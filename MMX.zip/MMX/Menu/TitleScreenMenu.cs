using SFML.Graphics;
using System;
using static SFML.Window.Keyboard;

namespace MMXOnline
{
    /// <summary>
    /// Pantalla de título:
    /// 1) mainmenutitle entra desde la izquierda hasta el centro (escalado para caber bien)
    /// 2) onlinedeathmatch entra desde la derecha, debajo del título
    /// 3) Al llegar: Idle con PRESS START (sin flash)
    /// 4) PRESS START (celeste) → animación transition1, transition2, ... → MainMenu
    ///
    /// Assets:
    ///   menubackground
    ///   mainmenutitle  ó  mainmenutitle1, mainmenutitle2, ...
    ///   onlinedeathmatch
    ///   transition1, transition2, ...
    ///   sonido "ching"
    /// </summary>
    public class TitleScreenMenu : IMainMenu
    {
        enum Phase
        {
            Enter,
            Idle,
            ExitTransition
        }

        Phase phase = Phase.Enter;

        float enterT;
        const float enterDuration = 0.85f;

        bool chingPlayed;

        float blinkTime;
        float idleInputDelay;
        const float blinkOn = 0.55f;
        const float blinkOff = 0.35f;

        float titleAnimTimer;
        int titleFrameIndex;
        int titleFrameCount;
        bool titleFramesCached;
        const float titleFrameDuration = 0.1f;
        const string titleFramePrefix = "mainmenutitle";
        const string titleStaticKey = "mainmenutitle";
        const string subtitleKey = "onlinedeathmatch";
        const string bgTextureKey = "menubackground";

        float transitionTimer;
        int transitionFrameIndex;
        int transitionFrameCount;
        bool transitionFramesCached;
        const float transitionFrameDuration = 0.06f;
        const string transitionFramePrefix = "transition";

        static readonly Color pressStartColor = new Color(100, 210, 255);

        bool musicStarted;

        public TitleScreenMenu()
        {
            phase = Phase.Enter;
            enterT = 0;
            chingPlayed = false;
            blinkTime = 0;
            idleInputDelay = 0;
            transitionTimer = 0;
            transitionFrameIndex = 0;
            transitionFrameCount = 0;
            transitionFramesCached = false;
        }

        int countFramesWithPrefix(string prefix)
        {
            int count = 0;
            for (int i = 1; i <= 256; i++)
            {
                if (Global.textures.ContainsKey(prefix + i))
                    count = i;
                else
                    break;
            }
            return count;
        }

        public void update()
        {
            if (!musicStarted)
            {
                musicStarted = true;
                try { Global.changeMusic("menu"); } catch { }
            }

            if (!titleFramesCached)
            {
                titleFrameCount = countFramesWithPrefix(titleFramePrefix);
                titleFramesCached = true;
            }

            updateTitleAnim();

            switch (phase)
            {
                case Phase.Enter:
                    updateEnter();
                    break;
                case Phase.Idle:
                    updateIdle();
                    break;
                case Phase.ExitTransition:
                    updateExitTransition();
                    break;
            }
        }

        void updateTitleAnim()
        {
            if (titleFrameCount <= 0) return;
            titleAnimTimer += Global.spf;
            if (titleAnimTimer >= titleFrameDuration)
            {
                titleAnimTimer -= titleFrameDuration;
                titleFrameIndex = (titleFrameIndex + 1) % titleFrameCount;
            }
        }

        void updateEnter()
        {
            enterT += Global.spf / enterDuration;
            if (enterT >= 1f)
            {
                enterT = 1f;
                phase = Phase.Idle;
                blinkTime = 0;
                idleInputDelay = 0;
                if (!chingPlayed)
                {
                    chingPlayed = true;
                    try { Global.playSound("ching"); } catch { }
                }
            }
        }

        void updateIdle()
        {
            blinkTime += Global.spf;
            if (blinkTime >= blinkOn + blinkOff)
                blinkTime = 0;

            idleInputDelay += Global.spf;
            if (idleInputDelay < 0.15f)
                return;

            bool pressStart =
                Global.input.isPressed(Key.Enter) ||
                Global.input.isPressed(Key.Space) ||
                Global.input.isPressedMenu(Control.MenuSelectPrimary) ||
                Global.input.isPressedMenu(Control.MenuSelectSecondary) ||
                Global.input.isPressedMenu(Control.MenuEnter) ||
                Global.input.isPressedMenu(Control.Jump) ||
                Global.input.isPressedMenu(Control.Shoot);

            if (pressStart)
            {
                if (!transitionFramesCached)
                {
                    transitionFrameCount = countFramesWithPrefix(transitionFramePrefix);
                    transitionFramesCached = true;
                }

                transitionFrameIndex = 0;
                transitionTimer = 0;
                chingPlayed = false;
                phase = Phase.ExitTransition;

                if (transitionFrameCount <= 0)
                    Menu.change(new MainMenu());
            }
        }

        void updateExitTransition()
        {
            if (!chingPlayed)
            {
                chingPlayed = true;
                try { Global.playSound("ching"); } catch { }
            }

            if (transitionFrameCount <= 0)
            {
                Menu.change(new MainMenu());
                return;
            }

            transitionTimer += Global.spf;
            if (transitionTimer >= transitionFrameDuration)
            {
                transitionTimer -= transitionFrameDuration;
                transitionFrameIndex++;
                if (transitionFrameIndex >= transitionFrameCount)
                    Menu.change(new MainMenu());
            }
        }

        public void render()
        {
            drawStaticBackground();

            float ease = easeOutCubic(Helpers.clamp01(enterT));
            drawTitleSliding(ease);
            drawSubtitleSliding(ease);

            if (phase == Phase.Idle)
            {
                if (blinkTime < blinkOn)
                {
                    Helpers.drawTextStd(
                        TCat.Default,
                        "PRESS START",
                        Global.screenW / 2f,
                        Global.screenH * 0.82f,
                        Alignment.Center,
                        fontSize: 24,
                        color: pressStartColor
                    );
                }
            }
            else if (phase == Phase.ExitTransition && transitionFrameCount > 0)
            {
                drawTransitionFrame();
            }

            Helpers.drawTextStd(
                TCat.Default,
                "v" + Global.version.ToString(System.Globalization.CultureInfo.InvariantCulture),
                Global.screenW - 6,
                Global.screenH - 14,
                Alignment.Right,
                fontSize: 12
            );
        }

        void drawTransitionFrame()
        {
            int frameNum = transitionFrameIndex + 1;
            if (frameNum < 1) frameNum = 1;
            if (frameNum > transitionFrameCount) frameNum = transitionFrameCount;

            string key = transitionFramePrefix + frameNum;
            if (!Global.textures.ContainsKey(key))
                return;

            Texture tex = Global.textures[key];
            float tw = tex.Size.X;
            float th = tex.Size.Y;
            if (tw <= 0 || th <= 0) return;

            float maxW = Global.screenW * 0.55f;
            float maxH = Global.screenH * 0.18f;
            float scale = Math.Min(maxW / tw, maxH / th);

            float drawW = tw * scale;
            float drawH = th * scale;
            float dx = (Global.screenW - drawW) / 2f;
            float dy = Global.screenH * 0.82f - drawH * 0.35f;

            DrawWrappers.DrawTexture(
                tex, 0, 0, tw, th,
                dx, dy, ZIndex.HUD,
                cx: 0, cy: 0,
                xScale: scale, yScale: scale,
                angle: 0, alpha: 1f,
                shaders: null, isWorldPos: false
            );
        }

        static float easeOutCubic(float t)
        {
            float u = 1f - t;
            return 1f - u * u * u;
        }

        void drawStaticBackground()
        {
            if (Global.textures.ContainsKey(bgTextureKey))
                DrawWrappers.DrawTextureHUD(Global.textures[bgTextureKey], 0, 0);
            else
            {
                DrawWrappers.DrawRect(
                    0, 0, Global.screenW, Global.screenH,
                    true, new Color(8, 5, 12), 0, ZIndex.Background, false
                );
            }
        }

        Texture getTitleTexture()
        {
            if (titleFrameCount > 0)
            {
                if (titleFrameIndex >= titleFrameCount)
                    titleFrameIndex = 0;
                string key = titleFramePrefix + (titleFrameIndex + 1);
                if (Global.textures.ContainsKey(key))
                    return Global.textures[key];
            }
            if (Global.textures.ContainsKey(titleStaticKey))
                return Global.textures[titleStaticKey];
            return null;
        }

        void drawTitleSliding(float ease)
        {
            Texture tex = getTitleTexture();
            if (tex == null)
            {
                float textX = lerp(-Global.screenW * 0.5f, Global.screenW / 2f, ease);
                Helpers.drawTextStd(
                    TCat.Title, "MEGA MAN X ONLINE",
                    textX, Global.screenH * 0.22f,
                    Alignment.Center, fontSize: 36
                );
                return;
            }

            float tw = tex.Size.X;
            float th = tex.Size.Y;
            if (tw <= 0 || th <= 0) return;

            float maxW = Global.screenW * 0.92f;
            float maxH = Global.screenH * 0.42f;
            float scale = Math.Min(maxW / tw, maxH / th);

            float drawW = tw * scale;
            float drawH = th * scale;
            float endX = (Global.screenW - drawW) / 2f;
            float startX = -drawW - 8f;
            float dx = lerp(startX, endX, ease);
            float dy = Global.screenH * 0.10f;

            DrawWrappers.DrawTexture(
                tex, 0, 0, tw, th,
                dx, dy, ZIndex.HUD,
                cx: 0, cy: 0,
                xScale: scale, yScale: scale,
                angle: 0, alpha: 1f,
                shaders: null, isWorldPos: false
            );
        }

        void drawSubtitleSliding(float ease)
        {
            if (!Global.textures.ContainsKey(subtitleKey))
                return;

            Texture tex = Global.textures[subtitleKey];
            float tw = tex.Size.X;
            float th = tex.Size.Y;
            if (tw <= 0 || th <= 0) return;

            float maxW = Global.screenW * 0.45f;
            float maxH = Global.screenH * 0.10f;
            float scale = Math.Min(maxW / tw, maxH / th) * 0.70f;

            float drawW = tw * scale;
            float drawH = th * scale;
            float endX = (Global.screenW - drawW) / 2f;
            float startX = Global.screenW + 8f;
            float dx = lerp(startX, endX, ease);
            float dy = Global.screenH * 0.40f;

            DrawWrappers.DrawTexture(
                tex, 0, 0, tw, th,
                dx, dy, ZIndex.HUD,
                cx: 0, cy: 0,
                xScale: scale, yScale: scale,
                angle: 0, alpha: 1f,
                shaders: null, isWorldPos: false
            );
        }

        static float lerp(float a, float b, float t)
        {
            return a + (b - a) * t;
        }
    }
}