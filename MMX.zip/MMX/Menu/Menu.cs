﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MMXOnline
{
    public class Menu
    {
        public static IMainMenu mainMenu;

        public static bool inMenu { get { return mainMenu != null; } }
        public static bool inChat { get { return chatMenu != null && chatMenu.typingChat; } }

        public static bool inControlMenu { get { return mainMenu is ControlMenu; } }

        public static ChatMenu chatMenu
        {
            get
            {
                ChatMenu chatMenu = Global.level?.gameMode?.chatMenu;
                return chatMenu;
            }
        }

        public static void change(IMainMenu newMenu)
        {
            //if (Global.level?.mainPlayer?.isUsingSubTank() == true) return;
            mainMenu = newMenu;
        }

        public static void exit()
        {
            mainMenu = null;
        }

        public static void update()
        {
            if (chatMenu != null)
            {
                chatMenu.update();
                if (chatMenu.typingChat) return;
                if (chatMenu.recentlyExited) return;
            }
            if (mainMenu != null && Global.level?.gameMode?.drawingScoreboard != true)
            {
                mainMenu.update();
            }
        }

        public static void render()
        {
            if (chatMenu != null)
            {
                chatMenu.render();
            }
            if (mainMenu != null && Global.level?.gameMode?.drawingScoreboard != true)
            {
                mainMenu.render();
            }
        }

        public static bool isHostEndMenu()
        {
            return mainMenu is HostMenu || mainMenu is ConfirmLeaveMenu;
        }

    }

    /// <summary>
    /// Fondo de menú estático: textura "menubackground".
    /// (Ya no usa la secuencia animada background1, background2, ...)
    /// </summary>
    public static class MenuBackgroundAnim
    {
        public const string StaticKey = "menubackground";

        public static void update()
        {
            // Sin animación
        }

        public static void draw()
        {
            if (Global.textures.ContainsKey(StaticKey))
            {
                DrawWrappers.DrawTextureHUD(Global.textures[StaticKey], 0, 0);
                return;
            }

            // Fallback sólido
            DrawWrappers.DrawRect(0, 0, Global.screenW, Global.screenH, true,
                new SFML.Graphics.Color(8, 5, 12), 0, ZIndex.Background, false);
        }
    }
}