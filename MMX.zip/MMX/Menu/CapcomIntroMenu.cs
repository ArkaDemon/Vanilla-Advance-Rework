using SFML.Graphics;
using System;
using static SFML.Window.Keyboard;

namespace MMXOnline
{
    /// <summary>
    /// Pantalla de intro del logo Capcom:
    /// fade in → espera con audio → fade out → pasa a la pantalla de título (Press Start).
    ///
    /// Assets necesarios:
    ///   assets/menu/capcom_logo.png
    ///   assets/sounds/capcom_jingle.ogg  (o .wav)
    /// </summary>
    public class CapcomIntroMenu : IMainMenu
    {
        enum Phase
        {
            FadeIn,
            Hold,
            FadeOut,
            Done
        }

        Phase phase = Phase.FadeIn;
        float alpha = 0f;
        float timer = 0f;
        bool jinglePlayed = false;
        bool missingAssets = false;

        // Duraciones (en segundos)
        const float fadeInDuration = 1.2f;
        const float holdDuration = 2.0f;
        const float fadeOutDuration = 1.0f;

        const string logoTextureKey = "capcomlogo";
        const string jingleSoundKey = "capcom_jingle";

        public CapcomIntroMenu()
        {
            // Si faltan assets, saltamos a la pantalla de título para no bloquear el juego
            if (!Global.textures.ContainsKey(logoTextureKey))
            {
                missingAssets = true;
            }
        }

        public void update()
        {
            if (missingAssets)
            {
                goToMainMenu();
                return;
            }

            // Permitir saltar la intro con Enter / Escape / botón de confirmar
            if (Global.input.isPressed(Key.Enter) ||
                Global.input.isPressed(Key.Escape) ||
                Global.input.isPressedMenu(Control.MenuSelectPrimary) ||
                Global.input.isPressedMenu(Control.MenuBack))
            {
                goToMainMenu();
                return;
            }

            timer += Global.spf;

            switch (phase)
            {
                case Phase.FadeIn:
                    alpha = Helpers.clamp01(timer / fadeInDuration);
                    if (!jinglePlayed && alpha > 0.05f)
                    {
                        playJingle();
                        jinglePlayed = true;
                    }
                    if (timer >= fadeInDuration)
                    {
                        alpha = 1f;
                        timer = 0f;
                        phase = Phase.Hold;
                    }
                    break;

                case Phase.Hold:
                    alpha = 1f;
                    if (timer >= holdDuration)
                    {
                        timer = 0f;
                        phase = Phase.FadeOut;
                    }
                    break;

                case Phase.FadeOut:
                    alpha = 1f - Helpers.clamp01(timer / fadeOutDuration);
                    if (timer >= fadeOutDuration)
                    {
                        alpha = 0f;
                        phase = Phase.Done;
                        goToMainMenu();
                    }
                    break;
            }
        }

        public void render()
        {
            // Fondo negro
            DrawWrappers.DrawRect(0, 0, Global.screenW, Global.screenH, true, Color.Black, 0, ZIndex.HUD, false);

            if (missingAssets || !Global.textures.ContainsKey(logoTextureKey))
            {
                return;
            }

            Texture logo = Global.textures[logoTextureKey];
            float tw = logo.Size.X;
            float th = logo.Size.Y;

            // Escalar si el logo es más grande que la pantalla (con un poco de margen)
            float maxW = Global.screenW * 0.85f;
            float maxH = Global.screenH * 0.7f;
            float scale = 1f;
            if (tw > maxW || th > maxH)
            {
                scale = Math.Min(maxW / tw, maxH / th);
            }

            float drawW = tw * scale;
            float drawH = th * scale;
            float dx = (Global.screenW - drawW) / 2f;
            float dy = (Global.screenH - drawH) / 2f;

            // Dibuja el logo centrado con alpha (fade)
            DrawWrappers.DrawTexture(
                logo,
                0, 0, tw, th,
                dx, dy,
                ZIndex.HUD,
                cx: 0, cy: 0,
                xScale: scale, yScale: scale,
                angle: 0,
                alpha: alpha,
                shaders: null,
                isWorldPos: false
            );
        }

        void playJingle()
        {
            if (Global.soundBuffers.ContainsKey(jingleSoundKey))
            {
                Global.playSound(jingleSoundKey);
            }
        }

        void goToMainMenu()
        {
            phase = Phase.Done;
            // No arrancar música aquí: TitleScreenMenu la inicia
            Menu.change(new TitleScreenMenu());
        }
    }
}