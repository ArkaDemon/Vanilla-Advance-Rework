using SFML.Graphics;
using System;
using System.Collections.Generic;
using static SFML.Window.Keyboard;

namespace MMXOnline
{
    public class PlayMenu : IMainMenu
    {
        public MainMenu prevMenu;
        public int selectY;

        static readonly string[] options = new string[]
        {
            "Join Match",
            "Create Match",
            "Offline",
            "Back"
        };

        public PlayMenu(MainMenu prevMenu)
        {
            this.prevMenu = prevMenu;
        }

        public void update()
        {
            MenuBackgroundAnim.update();
            Helpers.menuUpDown(ref selectY, 0, options.Length - 1);

            if (Global.input.isPressedMenu(Control.MenuSelectPrimary))
            {
                if (selectY == 0)
                    Menu.change(new PreJoinOrHostMenu(prevMenu, true));
                else if (selectY == 1)
                    Menu.change(new PreJoinOrHostMenu(prevMenu, false));
                else if (selectY == 2)
                    Menu.change(new HostMenu(prevMenu, null, true, false));
                else if (selectY == 3)
                    Menu.change(prevMenu);
            }
            else if (Global.input.isPressedMenu(Control.MenuBack))
            {
                Menu.change(prevMenu);
            }
        }

        public void render()
        {
            if (Global.textures.ContainsKey("menubackground"))
            {
                DrawWrappers.DrawTextureHUD(Global.textures["menubackground"], 0, 0);
            }
            else
            {
                DrawWrappers.DrawRect(0, 0, Global.screenW, Global.screenH, true, new Color(8, 5, 12), 0, ZIndex.Background, false);
            }
            float startX = 36;
            float startY = 70;
            float lineH = 22;

            for (int i = 0; i < options.Length; i++)
            {
                bool selected = selectY == i;
                float y = startY + i * lineH;

                if (selected)
                    Helpers.drawTextStd(TCat.Option, "♥  " + options[i], startX, y, selected: true, fontSize: 24);
                else
                    Helpers.drawTextStd(TCat.Option, "    " + options[i], startX, y, selected: false, fontSize: 24);
            }

            Helpers.drawTextStd(TCat.BotHelp, "[X] Choose   [Z] Back", Global.screenW / 2, Global.screenH - 18, Alignment.Center, fontSize: 18);
            Helpers.drawTextStd("MMXOnline", 6, Global.screenH - 14, Alignment.Left, fontSize: 12);
        }
    }
}